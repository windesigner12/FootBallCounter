package com.example.android.footballcounter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int ScoreTeamHome = 0;
    int ScoreTeamGuest = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    /**
     * Increase the score for Home by 6 point.
     */
    public void addTouchdownHome(View v) {
        ScoreTeamHome = ScoreTeamHome +6;
        displayForTeamHome(ScoreTeamHome);
    }

    /**
     * Increase the score for Home by 2 points.
     */
    public void addFieldGoalHome(View v) {
        ScoreTeamHome = ScoreTeamHome +2;
        displayForTeamHome(ScoreTeamHome);
    }

    /**
     * Increase the score for Home by 1 points.
     */
    public void addKickingTheBallHome(View v) {
        ScoreTeamHome = ScoreTeamHome +1;
        displayForTeamHome(ScoreTeamHome);
    }

    /**
     * Increase the score for Home by 2 points.
     */
    public void addTackleHome(View v) {
        ScoreTeamHome = ScoreTeamHome +2;
        displayForTeamHome(ScoreTeamHome);
    }
    /**
       * Increase the score for Guest by 6 point.
     */

    public void addTouchdownGuest(View v) {
        ScoreTeamGuest = ScoreTeamGuest +6;
        displayForTeamGuest(ScoreTeamGuest);
    }

    /**
     * Increase the score for Guest by 2 points.
     */
    public void addFieldGoalGuest(View v) {
        ScoreTeamGuest = ScoreTeamGuest +2;
        displayForTeamGuest(ScoreTeamGuest);
    }

    /**
     * Increase the score for Guest by 1 points.
     */
    public void addKickingTheBallGuest(View v) {
        ScoreTeamGuest = ScoreTeamGuest +1;
        displayForTeamGuest(ScoreTeamGuest);
    }

    /**
     * Increase the score for Guest by 2 points.
     */
    public void addTackleGuest(View v) {
        ScoreTeamGuest = ScoreTeamGuest +2;
        displayForTeamGuest(ScoreTeamGuest);
    }

    public void resetForTeam(View v) {
        ScoreTeamHome =0;
        ScoreTeamGuest =0;
        displayForTeamHome(ScoreTeamHome);
        displayForTeamGuest(ScoreTeamGuest);
    }
    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamHome(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_home_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForTeamGuest (int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_guest_score);
        scoreView.setText(String.valueOf(score));
    }
}